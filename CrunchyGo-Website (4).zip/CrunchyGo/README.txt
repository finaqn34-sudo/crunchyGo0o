CRUNCHYGO WEBSITE
Website company profile dengan tema biru muda.

CARA MEMBUKA:
1. Ekstrak file ZIP ini.
2. Buka Visual Studio Code.
3. Pilih File > Open Folder, lalu pilih folder CrunchyGo.
4. Buka index.html. Disarankan memakai ekstensi Live Server untuk preview.

STRUKTUR:
- index.html              halaman Home
- about.html              halaman About Us
- assets/css/style.css    desain website
- assets/js/main.js       menu responsif dan tahun footer
- assets/images/         foto owner

Foto lokal sudah disertakan. Foto produk lainnya memakai gambar dari Unsplash sehingga memerlukan koneksi internet.
